
package com.company.mule.rules;

import javax.xml.namespace.NamespaceContext;
import java.util.Iterator;
import java.util.Map;

public class DynamicNamespaceContext implements NamespaceContext {

    private Map<String,String> namespaces;

    public DynamicNamespaceContext(Map<String,String> namespaces) {
        this.namespaces = namespaces;
    }

    public String getNamespaceURI(String prefix) {
        return namespaces.get(prefix);
    }

    public String getPrefix(String uri) { return null; }

    public Iterator getPrefixes(String uri) {
        return namespaces.keySet().iterator();
    }
}
