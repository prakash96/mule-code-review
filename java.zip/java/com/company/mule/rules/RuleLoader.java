
package com.company.mule.rules;

import com.company.mule.model.RuleConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;

public class RuleLoader {

    public RuleConfig load(File file) throws Exception {

        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(file, RuleConfig.class);

    }
}
