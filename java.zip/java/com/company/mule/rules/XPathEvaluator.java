
package com.company.mule.rules;

import com.company.mule.model.Rule;
import com.company.mule.model.Violation;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.*;
import org.w3c.dom.*;

import java.io.File;
import java.util.*;

public class XPathEvaluator {

    public List<Violation> evaluate(File xmlFile, List<Rule> rules) throws Exception {

        List<Violation> violations = new ArrayList<>();

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);

        Document doc = factory.newDocumentBuilder().parse(xmlFile);

        NamespaceExtractor extractor = new NamespaceExtractor();
        Map<String,String> namespaces = extractor.extract(doc);

        XPathFactory xpathFactory = XPathFactory.newInstance();
        XPath xpath = xpathFactory.newXPath();

        xpath.setNamespaceContext(new DynamicNamespaceContext(namespaces));

        System.out.println("Scanning file: " + xmlFile.getCanonicalPath());
        for (Rule rule : rules) {

        	System.out.println("evaluate: " + rule);
        	
        	try {
        		NodeList nodes = (NodeList) xpath.evaluate(
                        rule.getXpath(),
                        doc,
                        XPathConstants.NODESET
                );

                if (nodes.getLength() > 0) {

                    violations.add(
                            new Violation(
                                    rule.getId(),
                                    rule.getDescription(),
                                    xmlFile.getName()
                            )
                    );
                }
        	}catch(Exception e) {
        		
        	}
            
        }

        return violations;
    }
}
