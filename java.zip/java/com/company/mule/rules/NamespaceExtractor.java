
package com.company.mule.rules;

import org.w3c.dom.*;

import java.util.HashMap;
import java.util.Map;

public class NamespaceExtractor {

    public Map<String, String> extract(Document doc) {

        Map<String, String> namespaces = new HashMap<>();

        Element root = doc.getDocumentElement();

        NamedNodeMap attributes = root.getAttributes();

        for (int i = 0; i < attributes.getLength(); i++) {

            Node attr = attributes.item(i);

            String name = attr.getNodeName();

            if (name.startsWith("xmlns:")) {

                String prefix = name.substring(6);

                namespaces.put(prefix, attr.getNodeValue());

            }

            if (name.equals("xmlns")) {

                namespaces.put("mule", attr.getNodeValue());
            }
        }

        return namespaces;
    }
}
