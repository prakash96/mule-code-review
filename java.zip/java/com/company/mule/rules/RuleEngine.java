
package com.company.mule.rules;

import com.company.mule.model.*;

import java.io.File;
import java.nio.file.*;
import java.util.*;

public class RuleEngine {

    public List<Violation> validate(File projectDir, File rulesFile) throws Exception {

        RuleLoader loader = new RuleLoader();
        RuleConfig config = loader.load(rulesFile);

        XPathEvaluator evaluator = new XPathEvaluator();

        List<Violation> violations = new ArrayList<>();

        Path muleDir = Paths.get(projectDir.getAbsolutePath(), "src/main/mule");

        if (!Files.exists(muleDir))
            return violations;

        Files.walk(muleDir)
                .filter(p -> p.toString().endsWith(".xml"))
                .forEach(path -> {

                    try {
                    	
                    	
                        violations.addAll(
                                evaluator.evaluate(
                                        path.toFile(),
                                        config.getRules()
                                )
                        );

                    } catch (Exception e) {

                        e.printStackTrace();
                    }

                });

        return violations;
    }
}
