
package com.company.mule.rules;

import com.company.mule.model.Violation;
import com.company.mule.report.HtmlReportGenerator;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.*;

import java.io.File;
import java.util.List;

@Mojo(name = "validate", defaultPhase = LifecyclePhase.VERIFY)
public class MuleRuleValidatorMojo extends AbstractMojo {

    @Parameter(defaultValue = "${project.basedir}", readonly = true)
    private File projectBaseDir;

    @Parameter(property = "rulesFile",
            defaultValue = "${project.basedir}/rules/mule-rules.json")
    private File rulesFile;

    @Parameter(defaultValue = "true")
    private boolean failBuild;

    public void execute() throws MojoExecutionException {

        try {

            RuleEngine engine = new RuleEngine();

            List<Violation> violations =
                    engine.validate(projectBaseDir, rulesFile);

            HtmlReportGenerator report = new HtmlReportGenerator();
            report.generate(violations);

            if (violations.isEmpty()) {

                getLog().info("No Mule rule violations found.");
                return;
            }

            getLog().error("Mule rule violations:");

            for (Violation v : violations) {

                getLog().error(
                        v.getRuleId()
                                + " : "
                                + v.getMessage()
                                + " ("
                                + v.getFile()
                                + ")"
                );
            }

            if (failBuild) {

                throw new MojoExecutionException(
                        "Mule rule validation failed"
                );
            }

        } catch (Exception e) {

            throw new MojoExecutionException(e.getMessage(), e);
        }
    }
}
