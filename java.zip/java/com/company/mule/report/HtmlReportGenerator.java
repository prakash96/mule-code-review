
package com.company.mule.report;

import com.company.mule.model.Violation;

import java.nio.file.*;
import java.util.List;

public class HtmlReportGenerator {

    public void generate(List<Violation> violations) throws Exception {

        StringBuilder html = new StringBuilder();

        html.append("<html><body>");
        html.append("<h2>Mule Code Review Report</h2>");
        html.append("<table border='1'>");

        html.append("<tr><th>Rule</th><th>Description</th><th>File</th></tr>");

        for(Violation v : violations){

            html.append("<tr>");
            html.append("<td>"+v.getRuleId()+"</td>");
            html.append("<td>"+v.getMessage()+"</td>");
            html.append("<td>"+v.getFile()+"</td>");
            html.append("</tr>");
        }

        html.append("</table></body></html>");

        Files.write(Paths.get("target/mule-rule-report.html"),
                html.toString().getBytes());
    }
}
