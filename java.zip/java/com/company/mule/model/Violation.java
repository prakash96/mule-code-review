
package com.company.mule.model;

public class Violation {

    private String ruleId;
    private String message;
    private String file;

    public Violation(String ruleId, String message, String file) {
        this.ruleId = ruleId;
        this.message = message;
        this.file = file;
    }

    public String getRuleId() { return ruleId; }
    public String getMessage() { return message; }
    public String getFile() { return file; }
}
