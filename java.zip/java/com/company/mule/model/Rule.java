
package com.company.mule.model;

public class Rule {

    private String id;
    private String category;
    private String severity;
    private String description;
    private String xpath;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getXpath() { return xpath; }
    public void setXpath(String xpath) { this.xpath = xpath; }
    
    @Override
    public String toString() {
    	// TODO Auto-generated method stub
    	return getId() + ":" + getXpath();
    }
}
